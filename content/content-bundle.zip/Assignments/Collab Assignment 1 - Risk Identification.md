---
tags:
  - Assignment
  - Collaborative
  - CS
---
**Scenario:**
	Assume you are a team of outside information security professionals who were just hired to increase security at *SmallBank*. *SmallBank* is a small one-branch bank. You were given the hastily-drawn diagram by the owner of the bank:

![[Pasted image 20230902214344.png]]

**Goal:**
	Identify as many potential threats/vulnerabilities as you can. Try to come up with at least 10 potential threats. (Do not worry about how likely the risk is. Both realistic and outlandish are ok. Assume whatever you like from the diagram. The goal is to get a good list of potential problems.) They do not have to include the Tenets of Cybersecurity discussed in the [[Tenets of Cyber Security]]

1) 'Server Room' is not secured behind a staff only location. - This has a higher risk of having unwanted persons enter the secured space.
2) There is no redundancy from management devices (switches, routers, APNs). - If one goes down, it takes the system down. In addition it means attacks can be focused on the singular host point to gather data.
3) Cabling takes potentially exposed paths depending on how cabling is run. - If the cabling is not secured and insulated properly, cables could be spliced in blind spots for physical access to the network.
4) No windows are specified in the diagram, but as this is a bank, screens display sensitive information. - Ties in with confidentiality; Screens should be setup in such a way that they are not easily visible from the lobby or the exterior with the bank being a seemingly ground-level building.
5) Security cameras should be included in this diagram as many modern systems have POE (Power Over Ethernet) cameras leading to a security office. - No security cameras are present in the diagram which is a lack of security in general. If there are cameras at this bank that do not use the POE protocol, they should be evaluated by cable security, angle of view/detection, and height. Higher up cabling with well managed cables mean less chance of physical interruptions.
6) Building off the previous bullet, there is no security office. - Security for a bank should be managed from a security office that is closed off from public spaces and close to the server room ideally. This ensures the physical safety of the data and in the event of a detected breach, a manual shut off for a branch to stop wireless attacks given the APN.
7) It is not specified whether data transmitted over cables is encrypted. - With sensitive information, such as bank information, data should be encrypted from end-to-end regardless of transmission method.
8) If the bank provides guest Wi-Fi, the network should be set up to block traffic to the closed network. If the Wi-Fi is for the bank's devices, it would be more secure to hard wire all the devices and encrypt data over cables, removing wireless attacks from within the network.
9) I notice there is no physical firewall being used to protect the network. This does not count out a virtual firewall, but some sort of firewall should be set up to secure the inbound and outbound traffic on the network.
10) There is no specified security measures for any staff rooms. The staff locations are available from the lobby