---
tags:
  - Assignment
  - Collaborative
  - CS
---
## **Scenario:**
You are provided with two sets of 7 case studies. The first set of case studies is fictional. Each of them fits well into a single domain. The attacks violate one or more tenants. The second set of case studies are real cases.

## **Goal - Set 1:**
*Figure out 1) which domain matches each case study and 2) which tenants were violated.*

#### **Fictional Case Study 1:** **Phishing Attack at CreativeTech**

>**Background**: CreativeTech is a mid-sized technology company specializing in innovative design solutions. With a diverse workforce, the company relies heavily on email communication and collaboration tools.

>**Incident**: On a seemingly ordinary day, employees at CreativeTech received an email that appeared to be from the company's IT department. The email contained a link to a website that looked identical to the company's internal portal and asked employees to update their passwords.

>**Attack**: Unbeknownst to the employees, the email was a phishing attack orchestrated by cybercriminals. Several employees clicked on the link and entered their credentials, unknowingly handing over their usernames and passwords to the attackers.

>**Consequences**:
>>***Unauthorized Access**:* The attackers gained access to sensitive company information, including intellectual property and customer data.
>>***Financial Loss**:* The company incurred significant financial losses due to the theft of proprietary information and the cost of remediation.
>>***Reputation Damage**:* News of the breach damaged CreativeTech's reputation, leading to a loss of trust among clients and partners.

**Question:** Which tenet or tenets did this attack violate?
*Confidentiality and Integrity*
**Question:** Which domain fits this fictional case study best?
*User*

#### **Fictional Case Study 2: Malware Infection at DesignHub**

>**Background**: DesignHub, a leading graphic design agency, employs a team of talented designers who rely on high-end workstations. These workstations are equipped with specialized design software and are interconnected to enable collaboration on client projects.

>**Incident**: An employee, eager to try a new design tool, downloaded a free version from an unverified source. Unfortunately, the downloaded file contained hidden malware disguised as legitimate software.

>**Attack**: Upon execution, the malware quickly spread across the workstations, encrypting essential design files. A ransom message appeared, demanding payment in cryptocurrency for the decryption key.

**Question:** Which tenet or tenets did this attack violate?
*Availability*
**Question:** Which domain fits this fictional case study best?
*Workstation*

#### **Fictional Case Study 3: Internal Sniffing at HealthCare Plus**

>**Background**: HealthCare Plus is a renowned medical facility with a secure local area network (LAN) containing sensitive patient records, medical histories, and billing information. The network is designed to facilitate communication between various departments.

>**Incident**: An insider with malicious intent, possibly a disgruntled employee, installed a network sniffer on a computer within the LAN without detection.

>**Attack**: The sniffer captured and logged sensitive patient information, including medical records and personal details, transmitted within the network over several weeks.

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this fictional case study best?


#### **Fictional Case Study 4: Firewall Bypass at TravelWorld**
>**Background**: TravelWorld, a popular online travel agency, operates a complex network infrastructure connecting its local area network (LAN) to the wide area network (WAN). This connection enables seamless integration with various travel partners and payment gateways.

>**Incident**: Cybercriminals, targeting TravelWorld's rich customer data, discovered a vulnerability in the company's firewall configuration.

>**Attack**: The attackers exploited the vulnerability to bypass the firewall, gaining unauthorized access to the internal network. They were then able to navigate through the network, accessing sensitive customer information.

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this fictional case study best?


#### **Fictional Case Study 5: Data Interception at GlobalBank**

>**Background**: GlobalBank, a multinational financial institution, operates a wide area network (WAN) that connects its branches and ATMs worldwide. The WAN facilitates real-time financial transactions and inter-branch communications.

>**Incident**: Attackers identified a weak point in the encryption used for data transmission between two major branches located in different countries.

>**Attack**: Using sophisticated techniques, they intercepted and decrypted data transmitted between the branches, gaining access to sensitive financial transactions and internal communications.

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this fictional case study best?


#### **Fictional Case Study 6: VPN Exploitation at RemoteTech**

>**Background**: RemoteTech, a tech company specializing in remote collaboration tools, has a largely remote workforce. Employees use VPNs to access company resources securely from various locations around the world.

>**Incident**: An attacker discovered a flaw in the company's VPN configuration, specifically in the authentication process.

>**Attack**: The attacker exploited the flaw to gain unauthorized remote access to the internal network, impersonating a legitimate remote employee. This allowed access to confidential project files and internal communications.

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this fictional case study best?


#### **Fictional Case Study 7: SQL Injection at ShopEase**

>**Background**: ShopEase, a thriving e-commerce platform, hosts a vast database of customer information, product listings, and transaction histories. The platform's website is the primary interface for customers to browse and purchase products.

>**Incident**: A hacker, aiming to exploit weaknesses in web applications, identified a vulnerability in the website's login page, where user input was not properly sanitized.

>**Attack**: Using SQL injection, the hacker manipulated the site's database queries, bypassing login restrictions, and gaining unauthorized access to customer accounts and administrative functions.

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this fictional case study best?


## **Goal - Set 2:**
*Find out which domain(s) are most relevant and which tenants were violated.*

#### **Target's Phishing Attack (2013)**

>**Background**: Target Corporation, a well-known U.S. retail giant, operates over 1,800 stores across North America. With a strong emphasis on technology to manage vast amounts of customer and transaction data, Target became the victim of one of the largest data breaches in history during the bustling 2013 holiday shopping season.

>**Incident**: The initial entry point for the attackers was through a phishing email sent to an HVAC contractor who had network access to Target for maintenance purposes. The email contained malicious software that captured the contractor's login credentials.

>**Attack**: Using the stolen credentials, the attackers infiltrated Target's network, moving stealthily to install malware on the point-of-sale systems. This malware captured credit and debit card information from millions of customers as they made purchases in stores.

**Source**: [Krebs on Security - Target Breach](https://krebsonsecurity.com/2014/02/target-hackers-broke-in-via-hvac-company/)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?

#### **WannaCry Ransomware Attack (2017)**

>**Background**: In May 2017, the world witnessed the rapid spread of the WannaCry ransomware, a malicious software that targeted computers running the Microsoft Windows operating system. Organizations across various sectors, including healthcare, transportation, and government, were affected in over 150 countries.

>**Incident**: The ransomware exploited a known vulnerability in Windows, for which a patch was available but not universally applied. Computers without the update were left exposed.

>**Attack**: Once a system was infected, the ransomware encrypted files and displayed a ransom message, demanding payment in Bitcoin for decryption. It also propagated itself to other vulnerable systems within networks, causing widespread disruption.

**Source**: [BBC - WannaCry Ransomware Attack](https://www.bbc.com/news/technology-39901382)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?


#### **Stuxnet Worm (2010)**

>**Background**: Stuxnet, discovered in 2010, was a highly sophisticated computer worm designed to target industrial systems. It marked a significant shift in cyber warfare, as it was capable of causing physical damage to infrastructure. Its primary target was Iranian nuclear facilities.

>**Incident**: The worm was introduced into the Iranian nuclear facility's internal network, possibly through an infected USB drive.

>**Attack**: Stuxnet searched for specific programmable logic controllers (PLCs) used in centrifuges and altered their spinning speed. This caused physical damage to the centrifuges while sending normal operation reports to the monitoring systems.

**Source**: [Symantec - W32.Stuxnet](https://www.symantec.com/security-center/writeup/2010-071400-3123-99)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?


#### **Sony Pictures Hack (2014)**

>**Background**: Sony Pictures Entertainment, a major film and television production company, became the target of a devastating cyberattack in November 2014. The attack was attributed to a group called "Guardians of Peace," and it had significant political and business ramifications.

>**Incident**: The attackers identified and exploited weaknesses in Sony's network security, allowing them to gain unauthorized access.

>**Attack**: Once inside the network, they stole and subsequently leaked unreleased films, confidential emails, and sensitive employee data, including salaries and personal information.

**Source**: [CNN - Sony Pictures Hack](https://www.cnn.com/2014/12/24/tech/gallery/sony-hack-timeline/index.html)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?


#### **Bangladesh Bank Heist (2016)**

>**Background**: The Bangladesh Bank, the central bank of Bangladesh, oversees international financial transactions through the SWIFT network. In February 2016, the bank became the target of one of the largest attempted bank thefts in history.

>**Incident**: Attackers successfully compromised the bank's system used for international transfers.

>**Attack**: They sent fraudulent money transfer requests through the SWIFT network, attempting to steal nearly $1 billion. Although most transactions were blocked, $81 million was successfully transferred to accounts in the Philippines.

**Source**: [Reuters - Bangladesh Bank Heist](https://www.reuters.com/article/us-cyber-heist-philippines/swift-warns-banks-on-cyber-heists-as-hack-sophistication-grows-idUSKBN15H1IE)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?


#### **Twitter Admin Tool Attack (2020)**

>**Background**: Twitter, a global social media platform, serves as a communication channel for celebrities, politicians, and individuals worldwide. In July 2020, Twitter faced a significant security incident that raised questions about the platform's internal security measures.

>**Incident**: Attackers targeted Twitter employees with access to internal tools, using phone spear-phishing techniques to manipulate them.

>**Attack**: By gaining access to an internal admin tool, the attackers were able to control various high-profile Twitter accounts, including those of Elon Musk, Barack Obama, and Apple, and posted fraudulent cryptocurrency requests.

**Source**: [Twitter - Update on Security Incident](https://blog.twitter.com/en_us/topics/company/2020/an-update-on-our-security-incident.html)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?


#### **Equifax Data Breach (2017)**

>**Background**: Equifax, one of the largest credit reporting agencies in the U.S., collects and maintains information on over 800 million individuals and 88 million businesses worldwide. In 2017, Equifax announced a data breach that exposed the personal information of 143 million consumers.

>**Incident**: The breach occurred due to a vulnerability in Apache Struts, a web application framework used by Equifax. Although a patch was available, it was not applied in a timely manner.

>**Attack**: Attackers exploited the vulnerability to gain access to Equifax's systems, where they accessed sensitive personal and financial information, including Social Security numbers, birth dates, and addresses.

**Source**: [FTC - Equifax Data Breach](https://www.ftc.gov/equifax-data-breach)

**Question:** Which tenet or tenets did this attack violate?

**Question:** Which domain fits this real case study best and why?