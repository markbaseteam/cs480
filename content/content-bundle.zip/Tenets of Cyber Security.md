---
tags:
  - CS
  - Notes
---
**C**onfidentiality
	The principle that information is accessible only to those authorized to have access. 
	E.g. Other people can’t see your phone or data.
**I**ntegrity
	The principle that data must remain consistent and unaltered from its intended state.
	E.g. Other people can’t delete or change your stuff on your phone.
**A**vailability
	The principle that information must be available when needed by those authorized to access it.
	E.g. Your ability to use your phone can’t be taken away (apart from legal bindings and in the T&C)

