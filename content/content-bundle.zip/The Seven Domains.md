## User
This domain covers individuals who access the information system. The weakest domain because it relies on the functionality of humans, which can be manipulated by outside factors.

**Types of Attacks**
- Violating Confidentiality
	- Looking over employee's shoulder at a computer screen
- Violating Integrity
	- Deleting information/files while someone goes to the bathroom
- Violating Availability
	- Changing employee's password without their consent

**Controls**
- User Authentication
- User Training
## Workstation
This domain covers individual devices. This can include desktops, laptops, phones, or any other device with access to corporate information.

**Types of Attacks**
- Violating Confidentiality
	- Software spying on the user
- Violating Integrity
	- Software that deletes or modifies your information
- Violating Availability
	- Ransomware

**Controls**
- Antivirus Software
- Patch Management


## LAN
This domain covers the internal/local network.

**Types of Attacks**
- Violating Confidentiality
	- Wiretapping
	- Packet Sniffing
- Violating Integrity
	- Changing information intercepted
- Violating Availability
	- Severing connections to resources

**Controls**
- Physical Firewalls
- Intrusion Detection Systems
## LAN to WAN
This domain covers the connection between local network and larger network that devices are attached to.

**Types of Attacks**
- Violating Confidentiality
	- Wiretapping inbound/outbound internet cables
- Violating Integrity
	- Replacing router with your own "custom" router that changes information like bank account numbers
- Violating Availability
	- Destroying physical devices such as the router

**Controls**
- VPNs
- Encryption
## WAN
This domain covers information outside the local network.

**Types of Attacks**
- Violating Confidentiality
	- Wiretapping a major internet cable from a remote location and collecting data without authorization
- Violating Integrity
	- Packet interception & changing the packet information
- Violating Availability
	- Packet spamming to slow down a website

**Controls**
- Secure Routing Protocols
- Monitoring
## Remote Access
This domain covers how employees/users remote access resources.

**Types of Attacks**
- Violating Confidentiality
	- Stealing your password and remote login in place of the desired user
- Violating Integrity
	- Changing account information
- Violating Integrity
	- Installing blocker software as the desired user

**Controls**
- MFA
- Secure Protocols
## System & Application
This domain covers servers, applications, and databases.

**Types of Attacks**
- Violating Confidentiality
	- Hacking into database remotely to view data
- Violating Integrity
	- Changing sensitive data
- Violating Availability
	- Logic bombs

**Controls**
- Secure coding practices
- Regular code audits